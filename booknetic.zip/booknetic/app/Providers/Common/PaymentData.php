<?php

namespace BookneticApp\Providers\Common;

class PaymentData
{

    public array $paymentId;
    public array $items = [];
    public array $customData = [];


}
