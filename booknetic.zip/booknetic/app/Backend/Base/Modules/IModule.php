<?php

namespace BookneticApp\Backend\Base\Modules;

interface IModule
{
}