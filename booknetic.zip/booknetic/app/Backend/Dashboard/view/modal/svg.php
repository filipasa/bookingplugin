<?php

\BookneticApp\Backend\Dashboard\Helpers\UIHelper::renderGraph( $parameters['startDate']  , $parameters['endDate']);

