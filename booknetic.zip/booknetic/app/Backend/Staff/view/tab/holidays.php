<?php defined( 'ABSPATH' ) or die(); ?>

<div class="yearly_calendar"></div>