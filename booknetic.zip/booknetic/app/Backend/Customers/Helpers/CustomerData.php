<?php

namespace BookneticApp\Backend\Customers\Helpers;

class CustomerData
{

    public $first_name;
    public $last_name;
    public $email;
    public $phone;

}